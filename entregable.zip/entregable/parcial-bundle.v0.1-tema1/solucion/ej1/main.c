#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <assert.h>

#include "ej1.h"
//extern char** agrupar_c(msg_t* msgArr, size_t msgArr_len);

int main (){
	/* Acá pueden realizar sus propias pruebas */

	msg_t msg1;
    msg1.text = "Hola ";
	msg1.text_len = 5;
	msg1.tag = 0;
    
    msg_t msg2;
	msg2.text = "Chau";
	msg2.text_len = 4;
	msg2.tag = 1;
    

	msg_t msg3;
	msg3.text = "Mundo";
	msg3.text_len = 5;
	msg3.tag = 0;
    

	msg_t arr[] = {msg1, msg2, msg3}; 
    
	char** res = agrupar(arr, 3);
	printf("%s\n", res[0]);
    printf("%s\n", res[1]);
	printf("%s\n", res[2]);
	printf("%s\n", res[3]);
	//printf("%d\n", sizeof(msg_t));

	char* res0 = res[0];
	char* res1 = res[1];

	// printf("%d\n" ,sizeof(msg_t));
	// printf("%d\n" ,sizeof(size_t));
	// printf("%d\n" ,sizeof(int));
	// printf("%d\n" ,sizeof(char*));
	return 0;
}


