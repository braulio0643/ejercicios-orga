#include <assert.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <argp.h>

#include "utils.h"
#include "ej2.h"

int main () {
   
	 
    

	/* Acá pueden realizar sus propias pruebas */
	
	/*printf("%d\n", sizeof(unsigned)); */
	/*int16_t entrada[] = {5,3,4,8,4,9,1,4,6,0,6,5,3,2,1,2,7,2,1,3,1,2};
	int16_t* salida = filtro(entrada, 11);
	int16_t salida1 = salida[0];
	int16_t salida2 = salida[1];
	int16_t salida3 = salida[2];
	int16_t* salidaCatedra = filtro_c(entrada, 11);
	int16_t salida1C = salidaCatedra[0];
	int16_t salida2C = salidaCatedra[1];
	int16_t salida3C = salidaCatedra[2];
	printf("%d\n", salida1);
	printf("%d\n", salida2);
	printf("%d\n", salida3);
	printf("%d\n", salida1C);
	printf("%d\n", salida2C);
	printf("%d\n", salida3C);*/
    
    int16_t* entrada =(int16_t*)malloc(7*4);
	
	for (unsigned i = 0; i < 7*2; i++){
		int a=rand();
		entrada[i]=a;
	   }

    int16_t* salida = (int16_t*) filtro(entrada,7);
    int16_t* salidaCatedra = (int16_t*) filtro_c(entrada,7);
	int16_t entrada1 = entrada[0];
	int16_t entrada2 = entrada[1];
	int16_t entrada3 = entrada[2];
    int16_t salida1 = salida[0];
	int16_t salida2 = salida[1];
	int16_t salida3 = salida[2];
    int16_t salida1C = salidaCatedra[0];
	int16_t salida2C = salidaCatedra[1];
	int16_t salida3C = salidaCatedra[2];
	printf("%d\n", entrada1);
	printf("%d\n", entrada2);
	printf("%d\n", entrada3);
    printf("%d\n", salida1);
	printf("%d\n", salida2);
	printf("%d\n", salida3);
	printf("%d\n", salida1C);
	printf("%d\n", salida2C);
	printf("%d\n", salida3C);
	return 0;
  
}

